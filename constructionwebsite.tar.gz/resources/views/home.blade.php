@extends('layouts.app')
@section('content')
<div class="container">
    <h1>&nbsp;</h1>
    <h1 class="text-primary">Welcome to Website Admin</h1>
    <hr>
</div>
@endsection
